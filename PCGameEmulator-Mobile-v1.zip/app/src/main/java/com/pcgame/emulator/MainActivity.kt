package com.pcgame.emulator

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit

class MainActivity : AppCompatActivity() {

    private val pickGame = 1001
    private lateinit var list: LinearLayout
    private val prefs by lazy { getSharedPreferences("games", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadGames()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 28)
        }

        val title = TextView(this).apply {
            text = "🎮 PC Game Emulator"
            textSize = 27f
            setPadding(0, 0, 0, 8)
        }
        page.addView(title)

        val subtitle = TextView(this).apply {
            text = "مكتبة ألعاب الكمبيوتر — الإصدار الأول"
            textSize = 16f
            setPadding(0, 0, 0, 22)
        }
        page.addView(subtitle)

        val add = Button(this).apply {
            text = "＋ إضافة لعبة من الهاتف"
            setOnClickListener { openPicker() }
        }
        page.addView(add, LinearLayout.LayoutParams(-1, -2))

        val note = TextView(this).apply {
            text = "ملاحظة: هذه النسخة تبني مكتبة الألعاب وواجهة المحاكي. تشغيل ملفات Windows فعليًا يحتاج محرك توافق سيتم دمجه في الإصدار التالي."
            textSize = 13f
            setPadding(0, 18, 0, 18)
        }
        page.addView(note)

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        page.addView(list)

        val controls = TextView(this).apply {
            text = "\n🕹️ لوحة التحكم\n\n        ▲\n   ◀    ●    ▶\n        ▼\n\nأزرار التحكم ستصبح قابلة للتخصيص عند إضافة محرك التشغيل."
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 20)
        }
        page.addView(controls)

        scroll.addView(page)
        setContentView(scroll)
    }

    private fun openPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, pickGame)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickGame && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                val name = uri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "لعبة جديدة" } ?: "لعبة جديدة"
                saveGame(name, uri.toString())
                addGameCard(name, uri.toString())
            }
        }
    }

    private fun saveGame(name: String, uri: String) {
        val old = prefs.getString("items", "") ?: ""
        val newItem = "$name|||$uri"
        prefs.edit { putString("items", if (old.isEmpty()) newItem else "$old###$newItem") }
    }

    private fun loadGames() {
        val data = prefs.getString("items", "") ?: ""
        if (data.isEmpty()) return
        data.split("###").forEach {
            val p = it.split("|||", limit = 2)
            if (p.size == 2) addGameCard(p[0], p[1])
        }
    }

    private fun addGameCard(name: String, uri: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
        }

        val title = TextView(this).apply {
            text = "🎮 $name"
            textSize = 18f
        }
        card.addView(title)

        val run = Button(this).apply {
            text = "▶ تشغيل"
            setOnClickListener {
                Toast.makeText(
                    this@MainActivity,
                    "تم اختيار اللعبة. محرك Windows سيُضاف في الإصدار القادم.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        card.addView(run)

        val settings = Button(this).apply {
            text = "⚙ إعدادات اللعبة"
            setOnClickListener {
                Toast.makeText(
                    this@MainActivity,
                    "إعدادات الجرافيك والتحكم ستُضاف مع محرك التشغيل.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        card.addView(settings)

        list.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, 0, 0, 18)
        })
    }
}
