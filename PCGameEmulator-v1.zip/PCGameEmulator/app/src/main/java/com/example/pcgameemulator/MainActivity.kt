package com.example.pcgameemulator

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi() }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(15,18,24)); setPadding(28,24,28,24) }
        val title=TextView(this).apply { text="PC GAME EMULATOR"; textSize=26f; setTextColor(Color.WHITE); gravity=Gravity.CENTER_VERTICAL }
        root.addView(title, LinearLayout.LayoutParams(-1,70))
        val sub=TextView(this).apply { text="محاكي ألعاب الكمبيوتر على Android • الإصدار 1"; textSize=15f; setTextColor(Color.LTGRAY) }
        root.addView(sub, LinearLayout.LayoutParams(-1,55))
        val add=Button(this).apply { text="＋ إضافة لعبة من الهاتف"; setOnClickListener { pickGame() } }
        root.addView(add, LinearLayout.LayoutParams(-1,65))
        list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,20,0,0) }
        val scroll=ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        val info=TextView(this).apply { text="المرحلة الأولى: إدارة مكتبة الألعاب. محرك تشغيل Windows سيتم ربطه في المرحلة التالية."; textSize=13f; setTextColor(Color.GRAY) }
        root.addView(info, LinearLayout.LayoutParams(-1,55))
        setContentView(root)
    }

    private fun pickGame() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="*/*"; addCategory(Intent.CATEGORY_OPENABLE); putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false) }
        startActivityForResult(i,100)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==100 && resultCode==RESULT_OK){ data?.data?.let{ addGame(it) } } }
    private fun addGame(uri:Uri) {
        val name=uri.lastPathSegment?.substringAfterLast('/') ?: "لعبة جديدة"
        val card=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(18,12,18,12); setBackgroundColor(Color.rgb(28,33,42)) }
        val t=TextView(this).apply { text="🎮  $name\n${uri}"; textSize=15f; setTextColor(Color.WHITE) }
        card.addView(t, LinearLayout.LayoutParams(0,80,1f))
        val play=Button(this).apply { text="تشغيل"; setOnClickListener { Toast.makeText(this@MainActivity,"سيتم تشغيل محرك اللعبة هنا في الإصدار القادم",Toast.LENGTH_LONG).show() } }
        card.addView(play, LinearLayout.LayoutParams(130,80))
        list.addView(card, LinearLayout.LayoutParams(-1,95).apply{bottomMargin=12})
    }
}
