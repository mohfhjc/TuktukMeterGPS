package com.example.location

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Real GPS tracker for the meter.
 * Only the GPS provider is used so network location cannot create fake movement.
 */
data class LocationUpdate(
    val speedKmh: Float = 0f,
    val distanceDeltaMeters: Double = 0.0,
    val isGpsActive: Boolean = false,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0
)

class LocationTracker(private val context: Context) {
    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private var lastLocation: Location? = null

    private val _locationUpdate = MutableStateFlow(LocationUpdate())
    val locationUpdate: StateFlow<LocationUpdate> = _locationUpdate.asStateFlow()

    companion object {
        private const val MAX_ACCURACY_METERS = 25f
        private const val MIN_MOVEMENT_METERS = 5.0
        private const val MAX_SINGLE_DELTA_METERS = 150.0
        private const val MOVING_SPEED_KMH = 3f
    }

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            // Ignore weak GPS fixes. This is the main protection against GPS drift while parked.
            if (location.provider != LocationManager.GPS_PROVIDER) return
            if (location.accuracy > MAX_ACCURACY_METERS) return

            val prev = lastLocation
            var deltaMeters = 0.0
            var calculatedSpeedKmh = 0f

            if (prev != null) {
                val distance = prev.distanceTo(location).toDouble()
                val timeSec = ((location.time - prev.time) / 1000.0).coerceAtLeast(0.5)
                calculatedSpeedKmh = ((distance / timeSec) * 3.6).toFloat()

                val gpsSpeedKmh = if (location.hasSpeed()) location.speed * 3.6f else calculatedSpeedKmh
                val movementSpeedKmh = if (location.hasSpeed()) gpsSpeedKmh else calculatedSpeedKmh

                // Count distance only when both displacement and speed indicate real movement.
                // Small GPS jumps while the vehicle is stationary are therefore ignored.
                if (distance >= MIN_MOVEMENT_METERS &&
                    distance <= MAX_SINGLE_DELTA_METERS &&
                    movementSpeedKmh >= MOVING_SPEED_KMH
                ) {
                    deltaMeters = distance
                }
            }

            val speed = if (location.hasSpeed()) {
                (location.speed * 3.6f).coerceAtLeast(0f)
            } else {
                calculatedSpeedKmh.coerceAtLeast(0f)
            }

            // Always advance the reference point after a good GPS fix.
            // This prevents accumulated parking drift from being counted later.
            lastLocation = location

            _locationUpdate.value = LocationUpdate(
                speedKmh = speed.coerceIn(0f, 120f),
                distanceDeltaMeters = deltaMeters,
                isGpsActive = true,
                latitude = location.latitude,
                longitude = location.longitude
            )
        }

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {
            if (provider == LocationManager.GPS_PROVIDER) {
                _locationUpdate.value = _locationUpdate.value.copy(isGpsActive = false, speedKmh = 0f)
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun startTracking() {
        lastLocation = null
        _locationUpdate.value = LocationUpdate(isGpsActive = false)
        try {
            val isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)

            if (isGpsEnabled) {
                locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    1000L,
                    1f,
                    locationListener,
                    Looper.getMainLooper()
                )
            }
        } catch (_: SecurityException) {
            _locationUpdate.value = LocationUpdate(isGpsActive = false)
        }
    }

    fun stopTracking() {
        try {
            locationManager.removeUpdates(locationListener)
        } catch (_: Exception) {}
        lastLocation = null
        _locationUpdate.value = LocationUpdate(isGpsActive = false)
    }

    fun reset() {
        lastLocation = null
    }
}
