package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trips")
data class TripEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val startTime: Long,
    val endTime: Long,
    val distanceKm: Double,
    val durationSeconds: Long,
    val waitingSeconds: Long,
    val fareAmount: Double,
    val currency: String = "ج.م",
    val baseFare: Double = 5.0,
    val ratePerKm: Double = 3.5,
    val ratePerMinWaiting: Double = 0.5,
    val note: String = ""
)
