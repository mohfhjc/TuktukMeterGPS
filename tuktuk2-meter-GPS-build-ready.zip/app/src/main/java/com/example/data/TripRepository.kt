package com.example.data

import kotlinx.coroutines.flow.Flow

class TripRepository(private val tripDao: TripDao) {
    val allTrips: Flow<List<TripEntity>> = tripDao.getAllTrips()
    val totalEarnings: Flow<Double?> = tripDao.getTotalEarnings()
    val totalDistanceKm: Flow<Double?> = tripDao.getTotalDistanceKm()
    val tripCount: Flow<Int> = tripDao.getTripCount()

    suspend fun insertTrip(trip: TripEntity): Long = tripDao.insertTrip(trip)
    suspend fun deleteTrip(trip: TripEntity) = tripDao.deleteTrip(trip)
    suspend fun clearAllTrips() = tripDao.clearAllTrips()
}
