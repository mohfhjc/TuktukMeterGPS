package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TripDao {
    @Query("SELECT * FROM trips ORDER BY startTime DESC")
    fun getAllTrips(): Flow<List<TripEntity>>

    @Query("SELECT * FROM trips WHERE id = :id")
    suspend fun getTripById(id: Long): TripEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrip(trip: TripEntity): Long

    @Delete
    suspend fun deleteTrip(trip: TripEntity)

    @Query("DELETE FROM trips")
    suspend fun clearAllTrips()

    @Query("SELECT SUM(fareAmount) FROM trips")
    fun getTotalEarnings(): Flow<Double?>

    @Query("SELECT SUM(distanceKm) FROM trips")
    fun getTotalDistanceKm(): Flow<Double?>

    @Query("SELECT COUNT(*) FROM trips")
    fun getTripCount(): Flow<Int>
}
