package com.example.data

import android.content.Context
import android.content.SharedPreferences

data class TariffConfig(
    val baseFare: Double = 5.0,
    val ratePerKm: Double = 3.5,
    val ratePerMinWaiting: Double = 0.5,
    val minFare: Double = 7.0,
    val currency: String = "ج.م",
    val simulationMode: Boolean = false
)

class TariffPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("tuktuk_tariff_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_BASE_FARE = "key_base_fare"
        private const val KEY_RATE_KM = "key_rate_km"
        private const val KEY_RATE_WAITING = "key_rate_waiting"
        private const val KEY_MIN_FARE = "key_min_fare"
        private const val KEY_CURRENCY = "key_currency"
        private const val KEY_SIMULATION = "key_simulation"
    }

    fun getTariff(): TariffConfig {
        return TariffConfig(
            baseFare = prefs.getFloat(KEY_BASE_FARE, 5.0f).toDouble(),
            ratePerKm = prefs.getFloat(KEY_RATE_KM, 3.5f).toDouble(),
            ratePerMinWaiting = prefs.getFloat(KEY_RATE_WAITING, 0.5f).toDouble(),
            minFare = prefs.getFloat(KEY_MIN_FARE, 7.0f).toDouble(),
            currency = prefs.getString(KEY_CURRENCY, "ج.م") ?: "ج.م",
            simulationMode = false
        )
    }

    fun saveTariff(tariff: TariffConfig) {
        prefs.edit()
            .putFloat(KEY_BASE_FARE, tariff.baseFare.toFloat())
            .putFloat(KEY_RATE_KM, tariff.ratePerKm.toFloat())
            .putFloat(KEY_RATE_WAITING, tariff.ratePerMinWaiting.toFloat())
            .putFloat(KEY_MIN_FARE, tariff.minFare.toFloat())
            .putString(KEY_CURRENCY, tariff.currency)
            .putBoolean(KEY_SIMULATION, false)
            .apply()
    }
}
