package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MeterColorScheme = darkColorScheme(
    primary = TukTukYellow,
    onPrimary = Color(0xFF101418),
    primaryContainer = Color(0xFF332700),
    onPrimaryContainer = TukTukYellowLight,
    secondary = MeterGreen,
    onSecondary = Color(0xFF003915),
    secondaryContainer = Color(0xFF005322),
    onSecondaryContainer = Color(0xFF6CFF99),
    tertiary = MeterCyan,
    onTertiary = Color(0xFF00363D),
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DarkBorder,
    error = MeterRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MeterColorScheme,
        typography = Typography,
        content = content
    )
}
