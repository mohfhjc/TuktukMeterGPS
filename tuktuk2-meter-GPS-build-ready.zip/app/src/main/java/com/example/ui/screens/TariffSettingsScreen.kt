package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TariffConfig
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.MeterAmber
import com.example.ui.theme.MeterGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TukTukYellow
import java.util.Locale

@Composable
fun TariffSettingsScreen(
    tariff: TariffConfig,
    onSaveTariff: (TariffConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    var baseFare by remember(tariff) { mutableStateOf(tariff.baseFare) }
    var rateKm by remember(tariff) { mutableStateOf(tariff.ratePerKm) }
    var rateWaiting by remember(tariff) { mutableStateOf(tariff.ratePerMinWaiting) }
    var minFare by remember(tariff) { mutableStateOf(tariff.minFare) }
    var currency by remember(tariff) { mutableStateOf(tariff.currency) }
    var simulationMode by remember(tariff) { mutableStateOf(tariff.simulationMode) }
    var showSavedNotification by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .verticalScroll(scrollState)
            .padding(bottom = 32.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "إعدادات تسعيرة التوك توك",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        Text(
            text = "اضبط سعر فتحة العداد والكيلومتر وزمن الانتظار حسب منطقتك",
            fontSize = 13.sp,
            color = TextSecondary
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Tariff items
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Base Fare
                TariffStepper(
                    label = "فتحة العداد الابتدائية",
                    sublabel = "المبلغ الذي يبدأ به العداد فور انطلاق الرحلة",
                    value = baseFare,
                    unit = currency,
                    step = 0.5,
                    onValueChange = { baseFare = it.coerceAtLeast(0.0) },
                    testTag = "base_fare_stepper"
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(DarkBorder)
                )

                // Rate per Km
                TariffStepper(
                    label = "سعر الكيلومتر",
                    sublabel = "الأجرة المحتسبة لكل كيلومتر تقطعه المركبة",
                    value = rateKm,
                    unit = "$currency / كم",
                    step = 0.25,
                    onValueChange = { rateKm = it.coerceAtLeast(0.0) },
                    testTag = "rate_km_stepper"
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(DarkBorder)
                )

                // Waiting rate per min
                TariffStepper(
                    label = "سعر دقيقة الانتظار",
                    sublabel = "تحتسب عند التوقف في إشارة أو زحام (أقل من 5 كم/س)",
                    value = rateWaiting,
                    unit = "$currency / دقيقة",
                    step = 0.1,
                    onValueChange = { rateWaiting = it.coerceAtLeast(0.0) },
                    testTag = "rate_waiting_stepper"
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(DarkBorder)
                )

                // Minimum Fare
                TariffStepper(
                    label = "الحد الأدنى للأجرة",
                    sublabel = "أقل مبلغ يمكن تحصيله لأي مشوار قصير",
                    value = minFare,
                    unit = currency,
                    step = 1.0,
                    onValueChange = { minFare = it.coerceAtLeast(0.0) },
                    testTag = "min_fare_stepper"
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Currency Selector Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "رمز العملة",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val currencies = listOf("ج.م", "د.ع", "ريال", "د.ك", "$", "LE")
                    currencies.forEach { curr ->
                        val isSelected = currency == curr
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) TukTukYellow else DarkSurfaceVariant)
                                .border(
                                    1.dp,
                                    if (isSelected) TukTukYellow else DarkBorder,
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { currency = curr }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = curr,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium,
                                color = if (isSelected) Color(0xFF101418) else TextSecondary
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Simulation Mode Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "وضع المحاكاة والتجربة",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MeterAmber.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "تجريبي",
                                fontSize = 10.sp,
                                color = MeterAmber,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "محاكاة حركة التوك توك والسرعة تلقائياً لاختبار العداد بدون الحاجة للتحرك بالسيارة.",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }

                Switch(
                    checked = simulationMode,
                    onCheckedChange = { simulationMode = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFF101418),
                        checkedTrackColor = TukTukYellow,
                        uncheckedThumbColor = TextMuted,
                        uncheckedTrackColor = DarkSurfaceVariant
                    ),
                    modifier = Modifier.testTag("simulation_switch")
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Save Button
        Button(
            onClick = {
                val updated = TariffConfig(
                    baseFare = baseFare,
                    ratePerKm = rateKm,
                    ratePerMinWaiting = rateWaiting,
                    minFare = minFare,
                    currency = currency,
                    simulationMode = simulationMode
                )
                onSaveTariff(updated)
                showSavedNotification = true
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("save_tariff_button"),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = TukTukYellow,
                contentColor = Color(0xFF101418)
            )
        ) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (showSavedNotification) "تم حفظ التسعيرة بنجاح!" else "حفظ التسعيرة الجديدة",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun TariffStepper(
    label: String,
    sublabel: String,
    value: Double,
    unit: String,
    step: Double,
    onValueChange: (Double) -> Unit,
    testTag: String
) {
    Column(modifier = Modifier.testTag(testTag)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
                Text(
                    text = sublabel,
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Stepper controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant)
                        .clickable {
                            val next = (value - step)
                            onValueChange(Math.round(next * 100.0) / 100.0)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Remove,
                        contentDescription = "Decrease",
                        tint = TextPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0C1014))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${String.format(Locale.US, "%.2f", value)} $unit",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = TukTukYellow
                    )
                }

                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant)
                        .clickable {
                            val next = (value + step)
                            onValueChange(Math.round(next * 100.0) / 100.0)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Increase",
                        tint = TextPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
