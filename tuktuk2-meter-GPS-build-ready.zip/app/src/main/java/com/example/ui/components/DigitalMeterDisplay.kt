package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TripStatus
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.MeterAmber
import com.example.ui.theme.MeterCyan
import com.example.ui.theme.MeterGreen
import com.example.ui.theme.MeterRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TukTukYellow
import java.util.Locale

@Composable
fun DigitalMeterDisplay(
    status: TripStatus,
    currentFare: Double,
    distanceKm: Double,
    speedKmh: Float,
    durationSeconds: Long,
    waitingSeconds: Long,
    currency: String,
    modifier: Modifier = Modifier
) {
    // Pulse animation for running state
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("digital_meter_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(
            2.dp,
            Brush.verticalGradient(
                colors = listOf(
                    when (status) {
                        TripStatus.RUNNING -> MeterGreen.copy(alpha = 0.8f)
                        TripStatus.PAUSED -> MeterAmber.copy(alpha = 0.8f)
                        TripStatus.STOPPED -> DarkBorder
                    },
                    DarkBorder
                )
            )
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Status bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Live Status Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            when (status) {
                                TripStatus.RUNNING -> MeterGreen.copy(alpha = 0.15f)
                                TripStatus.PAUSED -> MeterAmber.copy(alpha = 0.15f)
                                TripStatus.STOPPED -> DarkSurfaceVariant
                            }
                        )
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(
                                when (status) {
                                    TripStatus.RUNNING -> MeterGreen
                                    TripStatus.PAUSED -> MeterAmber
                                    TripStatus.STOPPED -> TextMuted
                                }
                            )
                            .then(
                                if (status == TripStatus.RUNNING) Modifier.alpha(pulseAlpha) else Modifier
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when (status) {
                            TripStatus.RUNNING -> "العداد يعمل | RUNNING"
                            TripStatus.PAUSED -> "متوقف مؤقتاً | PAUSED"
                            TripStatus.STOPPED -> "جاهز للانطلاق | READY"
                        },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (status) {
                            TripStatus.RUNNING -> MeterGreen
                            TripStatus.PAUSED -> MeterAmber
                            TripStatus.STOPPED -> TextSecondary
                        }
                    )
                }

                // Digital Clock Style Tag
                Text(
                    text = "METER 01",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TextMuted
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Giant Fare Display
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF090D12),
                                Color(0xFF131A22)
                            )
                        )
                    )
                    .border(1.dp, Color(0xFF263342), RoundedCornerShape(16.dp))
                    .padding(vertical = 18.dp, horizontal = 12.dp)
            ) {
                Text(
                    text = "الأجرة الإجمالية / TOTAL FARE",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TukTukYellow.copy(alpha = 0.85f),
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = String.format(Locale.US, "%.2f", currentFare),
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        color = TukTukYellow,
                        modifier = Modifier.testTag("current_fare_text")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = currency,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TukTukYellow.copy(alpha = 0.9f),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Telemetry Gauges Grid (2x2)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "المسافة / DIST",
                    value = String.format(Locale.US, "%.2f", distanceKm),
                    unit = "كم / KM",
                    icon = Icons.Default.Navigation,
                    accentColor = MeterCyan,
                    modifier = Modifier.weight(1f),
                    testTag = "distance_metric"
                )
                MetricCard(
                    title = "السرعة / SPEED",
                    value = String.format(Locale.US, "%02d", speedKmh.toInt()),
                    unit = "كم/س / KMH",
                    icon = Icons.Default.Speed,
                    accentColor = if (speedKmh > 35f) MeterAmber else MeterGreen,
                    modifier = Modifier.weight(1f),
                    testTag = "speed_metric"
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "الوقت / TIME",
                    value = formatDuration(durationSeconds),
                    unit = "دقيقة:ثانية",
                    icon = Icons.Default.Timer,
                    accentColor = TextPrimary,
                    modifier = Modifier.weight(1f),
                    testTag = "time_metric"
                )
                MetricCard(
                    title = "الانتظار / WAIT",
                    value = formatDuration(waitingSeconds),
                    unit = "دقيقة:ثانية",
                    icon = Icons.Default.HourglassBottom,
                    accentColor = if (waitingSeconds > 0) MeterAmber else TextMuted,
                    modifier = Modifier.weight(1f),
                    testTag = "waiting_metric"
                )
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    unit: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Box(
        modifier = modifier
            .testTag(testTag)
            .clip(RoundedCornerShape(16.dp))
            .background(DarkSurfaceVariant)
            .border(1.dp, DarkBorder, RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSecondary
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = value,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = accentColor
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = unit,
                    fontSize = 11.sp,
                    color = TextMuted,
                    modifier = Modifier.padding(bottom = 3.dp)
                )
            }
        }
    }
}

fun formatDuration(seconds: Long): String {
    val mins = seconds / 60
    val secs = seconds % 60
    return String.format(Locale.US, "%02d:%02d", mins, secs)
}
