package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TukTukYellow = Color(0xFFFFC107)
val TukTukYellowDark = Color(0xFFFFA000)
val TukTukYellowLight = Color(0xFFFFD54F)

val MeterGreen = Color(0xFF00E676)
val MeterGreenDark = Color(0xFF00B0FF)
val MeterRed = Color(0xFFFF3D57)
val MeterAmber = Color(0xFFFFAB00)
val MeterCyan = Color(0xFF00E5FF)

val DarkBackground = Color(0xFF0D1117)
val DarkSurface = Color(0xFF161C24)
val DarkSurfaceVariant = Color(0xFF222936)
val DarkBorder = Color(0xFF2E3846)

val TextPrimary = Color(0xFFF0F4F8)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
