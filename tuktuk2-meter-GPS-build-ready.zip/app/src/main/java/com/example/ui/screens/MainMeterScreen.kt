package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.ElectricRickshaw
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.GpsNotFixed
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.ToggleOff
import androidx.compose.material.icons.filled.ToggleOn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MeterUiState
import com.example.ui.TariffPreset
import com.example.ui.TripStatus
import com.example.ui.components.DigitalMeterDisplay
import com.example.ui.components.TripReceiptDialog
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.MeterAmber
import com.example.ui.theme.MeterCyan
import com.example.ui.theme.MeterGreen
import com.example.ui.theme.MeterRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TukTukYellow
import java.util.Locale

@Composable
fun MainMeterScreen(
    uiState: MeterUiState,
    onStartTrip: () -> Unit,
    onPauseTrip: () -> Unit,
    onResumeTrip: () -> Unit,
    onEndTrip: () -> Unit,
    onResetMeter: () -> Unit,
    onPresetSelected: (TariffPreset) -> Unit,
    onToggleSimulation: (Boolean) -> Unit,
    onDismissReceipt: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Preset & GPS Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Presets
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PresetBadge(
                        title = "عادي",
                        subtitle = "1.0x",
                        isSelected = uiState.activePreset == TariffPreset.STANDARD,
                        onClick = { onPresetSelected(TariffPreset.STANDARD) },
                        testTag = "preset_standard"
                    )
                    PresetBadge(
                        title = "ليلي",
                        subtitle = "1.25x",
                        isSelected = uiState.activePreset == TariffPreset.NIGHT,
                        onClick = { onPresetSelected(TariffPreset.NIGHT) },
                        testTag = "preset_night"
                    )
                    PresetBadge(
                        title = "مميز",
                        subtitle = "1.5x",
                        isSelected = uiState.activePreset == TariffPreset.SPECIAL,
                        onClick = { onPresetSelected(TariffPreset.SPECIAL) },
                        testTag = "preset_special"
                    )
                }

                // GPS / Simulation Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            if (uiState.tariff.simulationMode) MeterAmber.copy(alpha = 0.15f)
                            else if (uiState.isGpsActive) MeterGreen.copy(alpha = 0.15f)
                            else DarkSurfaceVariant
                        )
                        .clickable { onToggleSimulation(!uiState.tariff.simulationMode) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("simulation_toggle_pill")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (uiState.tariff.simulationMode) Icons.Default.ElectricRickshaw
                            else if (uiState.isGpsActive) Icons.Default.GpsFixed
                            else Icons.Default.GpsNotFixed,
                            contentDescription = null,
                            tint = if (uiState.tariff.simulationMode) MeterAmber
                            else if (uiState.isGpsActive) MeterGreen
                            else TextMuted,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = if (uiState.tariff.simulationMode) "تجربة" else "GPS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (uiState.tariff.simulationMode) MeterAmber
                            else if (uiState.isGpsActive) MeterGreen
                            else TextMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // The Main Digital Taximeter
            DigitalMeterDisplay(
                status = uiState.status,
                currentFare = uiState.currentFare,
                distanceKm = uiState.distanceKm,
                speedKmh = uiState.speedKmh,
                durationSeconds = uiState.tripDurationSeconds,
                waitingSeconds = uiState.waitingDurationSeconds,
                currency = uiState.tariff.currency
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Active Tariff Card summary
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TariffItem(
                        label = "الفتحة",
                        value = "${String.format(Locale.US, "%.1f", uiState.tariff.baseFare)} ${uiState.tariff.currency}"
                    )
                    Box(
                        modifier = Modifier
                            .height(24.dp)
                            .width(1.dp)
                            .background(DarkBorder)
                    )
                    TariffItem(
                        label = "الكيلومتر",
                        value = "${String.format(Locale.US, "%.1f", uiState.tariff.ratePerKm)} ${uiState.tariff.currency}"
                    )
                    Box(
                        modifier = Modifier
                            .height(24.dp)
                            .width(1.dp)
                            .background(DarkBorder)
                    )
                    TariffItem(
                        label = "الانتظار/د",
                        value = "${String.format(Locale.US, "%.1f", uiState.tariff.ratePerMinWaiting)} ${uiState.tariff.currency}"
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Primary Control Buttons (Large & Tactile for driving)
            when (uiState.status) {
                TripStatus.STOPPED -> {
                    Button(
                        onClick = onStartTrip,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(64.dp)
                            .testTag("start_trip_button"),
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MeterGreen,
                            contentColor = Color(0xFF003311)
                        ),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ابدأ الرحلة | START",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }

                TripStatus.RUNNING -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = onPauseTrip,
                            modifier = Modifier
                                .weight(1f)
                                .height(64.dp)
                                .testTag("pause_trip_button"),
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MeterAmber,
                                contentColor = Color(0xFF332000)
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Pause,
                                contentDescription = null,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "إيقاف مؤقت",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = onEndTrip,
                            modifier = Modifier
                                .weight(1f)
                                .height(64.dp)
                                .testTag("end_trip_button"),
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MeterRed,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = null,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "إنهاء وحساب",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                TripStatus.PAUSED -> {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = onResumeTrip,
                                modifier = Modifier
                                    .weight(1.2f)
                                    .height(60.dp)
                                    .testTag("resume_trip_button"),
                                shape = RoundedCornerShape(20.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MeterGreen,
                                    contentColor = Color(0xFF003311)
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "استئناف",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Button(
                                onClick = onEndTrip,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(60.dp)
                                    .testTag("end_trip_paused_button"),
                                shape = RoundedCornerShape(20.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MeterRed,
                                    contentColor = Color.White
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Stop,
                                    contentDescription = null,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "إنهاء",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = onResetMeter,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("reset_trip_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("إلغاء وإعادة تصفير العداد")
                        }
                    }
                }
            }
        }

        // Trip Receipt Dialog overlay
        if (uiState.showReceipt && uiState.lastCompletedTrip != null) {
            TripReceiptDialog(
                trip = uiState.lastCompletedTrip,
                onDismiss = onDismissReceipt
            )
        }
    }
}

@Composable
private fun PresetBadge(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Box(
        modifier = Modifier
            .testTag(testTag)
            .clip(RoundedCornerShape(14.dp))
            .background(if (isSelected) TukTukYellow else DarkSurfaceVariant)
            .border(
                1.dp,
                if (isSelected) TukTukYellow else DarkBorder,
                RoundedCornerShape(14.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color(0xFF12161A) else TextSecondary
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = if (isSelected) Color(0xFF332700) else TextMuted
            )
        }
    }
}

@Composable
private fun TariffItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = TextSecondary
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = TukTukYellow
        )
    }
}
