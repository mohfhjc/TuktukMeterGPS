package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.TariffConfig
import com.example.data.TariffPreferences
import com.example.data.TripEntity
import com.example.data.TripRepository
import com.example.location.LocationTracker
import com.example.util.HapticFeedbackHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

enum class TripStatus {
    STOPPED, RUNNING, PAUSED
}

enum class TariffPreset {
    STANDARD, NIGHT, SPECIAL
}

data class MeterUiState(
    val status: TripStatus = TripStatus.STOPPED,
    val currentFare: Double = 0.0,
    val distanceKm: Double = 0.0,
    val speedKmh: Float = 0f,
    val tripDurationSeconds: Long = 0L,
    val waitingDurationSeconds: Long = 0L,
    val tariff: TariffConfig = TariffConfig(),
    val activePreset: TariffPreset = TariffPreset.STANDARD,
    val isGpsActive: Boolean = false,
    val lastCompletedTrip: TripEntity? = null,
    val showReceipt: Boolean = false,
    val allTrips: List<TripEntity> = emptyList(),
    val totalEarnings: Double = 0.0,
    val totalDistanceKm: Double = 0.0,
    val totalTripsCount: Int = 0
)

class MeterViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = TripRepository(database.tripDao())
    private val tariffPreferences = TariffPreferences(application)
    val locationTracker = LocationTracker(application)
    private val hapticHelper = HapticFeedbackHelper(application)

    private val _uiState = MutableStateFlow(
        MeterUiState(
            tariff = tariffPreferences.getTariff(),
            currentFare = tariffPreferences.getTariff().baseFare
        )
    )
    val uiState: StateFlow<MeterUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null
    private var tripStartTime: Long = 0L

    init {
        // Collect DB state
        viewModelScope.launch {
            repository.allTrips.collect { trips ->
                _uiState.update { it.copy(allTrips = trips) }
            }
        }
        viewModelScope.launch {
            repository.totalEarnings.collect { earnings ->
                _uiState.update { it.copy(totalEarnings = earnings ?: 0.0) }
            }
        }
        viewModelScope.launch {
            repository.totalDistanceKm.collect { distance ->
                _uiState.update { it.copy(totalDistanceKm = distance ?: 0.0) }
            }
        }
        viewModelScope.launch {
            repository.tripCount.collect { count ->
                _uiState.update { it.copy(totalTripsCount = count) }
            }
        }

        // Collect GPS updates
        viewModelScope.launch {
            locationTracker.locationUpdate.collect { update ->
                if (_uiState.value.status == TripStatus.RUNNING) {
                    val additionalKm = update.distanceDeltaMeters / 1000.0
                    val newDist = _uiState.value.distanceKm + additionalKm
                    _uiState.update { current ->
                        current.copy(
                            distanceKm = newDist,
                            speedKmh = update.speedKmh,
                            isGpsActive = update.isGpsActive
                        )
                    }
                    recalculateFare()
                } else {
                    _uiState.update { it.copy(isGpsActive = update.isGpsActive) }
                }
            }
        }
    }

    fun startTrip() {
        hapticHelper.startTripAlert()
        tripStartTime = System.currentTimeMillis()
        locationTracker.reset()
        locationTracker.startTracking()

        val base = getEffectiveTariff().baseFare
        _uiState.update {
            it.copy(
                status = TripStatus.RUNNING,
                distanceKm = 0.0,
                speedKmh = 0f,
                tripDurationSeconds = 0L,
                waitingDurationSeconds = 0L,
                currentFare = base,
                showReceipt = false,
                lastCompletedTrip = null
            )
        }

        startTimerLoop()
    }

    fun pauseTrip() {
        hapticHelper.click()
        _uiState.update { it.copy(status = TripStatus.PAUSED, speedKmh = 0f) }
    }

    fun resumeTrip() {
        hapticHelper.click()
        _uiState.update { it.copy(status = TripStatus.RUNNING) }
    }

    fun endTrip(note: String = "") {
        hapticHelper.endTripAlert()
        timerJob?.cancel()
        locationTracker.stopTracking()

        val currentState = _uiState.value
        val effectiveTariff = getEffectiveTariff()
        val finalFare = calculateFare(
            distanceKm = currentState.distanceKm,
            waitingSeconds = currentState.waitingDurationSeconds,
            tariff = effectiveTariff
        )

        val completedTrip = TripEntity(
            startTime = tripStartTime,
            endTime = System.currentTimeMillis(),
            distanceKm = (currentState.distanceKm * 100.0).roundToInt() / 100.0,
            durationSeconds = currentState.tripDurationSeconds,
            waitingSeconds = currentState.waitingDurationSeconds,
            fareAmount = (finalFare * 100.0).roundToInt() / 100.0,
            currency = effectiveTariff.currency,
            baseFare = effectiveTariff.baseFare,
            ratePerKm = effectiveTariff.ratePerKm,
            ratePerMinWaiting = effectiveTariff.ratePerMinWaiting,
            note = note.trim()
        )

        viewModelScope.launch {
            repository.insertTrip(completedTrip)
        }

        _uiState.update {
            it.copy(
                status = TripStatus.STOPPED,
                speedKmh = 0f,
                currentFare = finalFare,
                lastCompletedTrip = completedTrip,
                showReceipt = true
            )
        }
    }

    fun resetMeter() {
        hapticHelper.click()
        timerJob?.cancel()
        locationTracker.stopTracking()
        locationTracker.reset()
        val base = getEffectiveTariff().baseFare
        _uiState.update {
            it.copy(
                status = TripStatus.STOPPED,
                currentFare = base,
                distanceKm = 0.0,
                speedKmh = 0f,
                tripDurationSeconds = 0L,
                waitingDurationSeconds = 0L,
                showReceipt = false,
                lastCompletedTrip = null
            )
        }
    }

    fun dismissReceipt() {
        _uiState.update { it.copy(showReceipt = false) }
    }

    fun setPreset(preset: TariffPreset) {
        hapticHelper.click()
        _uiState.update { it.copy(activePreset = preset) }
        recalculateFare()
    }

    fun updateTariff(newTariff: TariffConfig) {
        tariffPreferences.saveTariff(newTariff)
        _uiState.update { it.copy(tariff = newTariff) }
        recalculateFare()
    }

    fun toggleSimulation(enabled: Boolean) {
        // Real meter only: simulation is intentionally disabled.
        val updated = _uiState.value.tariff.copy(simulationMode = false)
        updateTariff(updated)
    }

    fun deleteTrip(trip: TripEntity) {
        viewModelScope.launch {
            repository.deleteTrip(trip)
        }
    }

    fun clearAllTrips() {
        viewModelScope.launch {
            repository.clearAllTrips()
        }
    }

    private fun startTimerLoop() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                val currentState = _uiState.value

                when (currentState.status) {
                    TripStatus.RUNNING -> {
                        val newDuration = currentState.tripDurationSeconds + 1

                        // GPS-only mode. Waiting time is counted only after a valid GPS fix.
                        val isWaiting = currentState.isGpsActive && currentState.speedKmh < 5f
                        val newWaiting = if (isWaiting) {
                            currentState.waitingDurationSeconds + 1
                        } else {
                            currentState.waitingDurationSeconds
                        }
                        _uiState.update {
                            it.copy(
                                tripDurationSeconds = newDuration,
                                waitingDurationSeconds = newWaiting,
                                speedKmh = if (!currentState.isGpsActive) 0f else currentState.speedKmh
                            )
                        }
                        recalculateFare()
                    }

                    TripStatus.PAUSED -> {
                        // While paused, duration and waiting time increase
                        val newDuration = currentState.tripDurationSeconds + 1
                        val newWaiting = currentState.waitingDurationSeconds + 1
                        _uiState.update {
                            it.copy(
                                tripDurationSeconds = newDuration,
                                waitingDurationSeconds = newWaiting
                            )
                        }
                        recalculateFare()
                    }

                    TripStatus.STOPPED -> {
                        break
                    }
                }
            }
        }
    }

    private fun getEffectiveTariff(): TariffConfig {
        val base = _uiState.value.tariff
        return when (_uiState.value.activePreset) {
            TariffPreset.STANDARD -> base
            TariffPreset.NIGHT -> base.copy(
                baseFare = base.baseFare * 1.25,
                ratePerKm = base.ratePerKm * 1.25,
                ratePerMinWaiting = base.ratePerMinWaiting * 1.25,
                minFare = base.minFare * 1.25
            )
            TariffPreset.SPECIAL -> base.copy(
                baseFare = base.baseFare * 1.5,
                ratePerKm = base.ratePerKm * 1.5,
                ratePerMinWaiting = base.ratePerMinWaiting * 1.5,
                minFare = base.minFare * 1.5
            )
        }
    }

    private fun calculateFare(distanceKm: Double, waitingSeconds: Long, tariff: TariffConfig): Double {
        val distanceFare = distanceKm * tariff.ratePerKm
        val waitingMinutes = waitingSeconds / 60.0
        val waitingFare = waitingMinutes * tariff.ratePerMinWaiting
        val rawFare = tariff.baseFare + distanceFare + waitingFare
        return maxOf(tariff.minFare, rawFare)
    }

    private fun recalculateFare() {
        val tariff = getEffectiveTariff()
        val current = _uiState.value
        val newFare = calculateFare(current.distanceKm, current.waitingDurationSeconds, tariff)
        _uiState.update { it.copy(currentFare = newFare) }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
        locationTracker.stopTracking()
    }
}
