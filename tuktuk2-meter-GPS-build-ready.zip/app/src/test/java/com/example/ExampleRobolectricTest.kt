package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.TariffConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("TukTuk Meter", appName)
  }

  @Test
  fun `verify tariff fare calculation`() {
    val tariff = TariffConfig(
      baseFare = 5.0,
      ratePerKm = 3.0,
      ratePerMinWaiting = 0.5,
      minFare = 8.0
    )
    // 2 km trip, 4 minutes wait
    val distanceCost = 2.0 * tariff.ratePerKm // 6.0
    val waitCost = 4.0 * tariff.ratePerMinWaiting // 2.0
    val total = tariff.baseFare + distanceCost + waitCost // 5 + 6 + 2 = 13.0
    assertEquals(13.0, total, 0.001)

    // Short trip test below minFare
    val shortTripRaw = tariff.baseFare + (0.5 * tariff.ratePerKm) // 5 + 1.5 = 6.5
    val actualFare = maxOf(tariff.minFare, shortTripRaw)
    assertEquals(8.0, actualFare, 0.001)
  }
}
